var show = document.getElementById('navlinks')

function showMenu() {
    show.style.right = "0";

}

function closeMenu() {
    show.style.right = "-50%";
}